package exam03;

class Shape{
	private int x,y;
	Shape(int x, int y){ this.x=x;  this.y=y; }
	public void draw() { System.out.println("("+x+","+y+")�� ������ �׸�"); }
}

public class ShapeTest {
	public static void main(String[] args) {
//		Shape[] shapes= new Shape[3];		
//		for(int i=0 ; i< shapes.length ; i++){
//			shapes[i] = new Shape(i,i);
//		}
		Shape[] shapes={
				new Shape(0,0),
				new Shape(1,1),
				new Shape(2,2),
		};
		
		for(Shape s : shapes)
			s.draw();
	}
}
