alist = [-10.6, 0, 1, 18, 23.6, 45, 63, 86.1]
print(alist)
afind = eval(input("찾는 숫자를 입력하세요: "))
print(afind,"는 ",(alist.index(afind))+1,"번째 방에 있습니다.")
