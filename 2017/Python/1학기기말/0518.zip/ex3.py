alist = ['A','B','C']
for i in alist:
    print("안녕 "+i)
for i in range(0,3):
    print("안녕",alist[i])
