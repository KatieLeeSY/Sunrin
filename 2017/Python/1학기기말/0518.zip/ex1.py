pockets = [4,5,3,9]
for i in range(0,4):
    pockets[i]=(i+1)
pockets.append(5)

print(pockets)
