alist=['a','b','c']
blist=['r','a','p']
clist=['c','l','e']
dlist=blist[1:3]
dlist+=blist[2:3]
dlist+=clist[1:3]
print(dlist)
