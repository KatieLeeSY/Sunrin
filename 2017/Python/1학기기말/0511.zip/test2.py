fhand = open('test.txt','w')
line1 = 'Hey Jude, don\'t make it bad'

fhand.write(line1)

fhand.close();
